@echo off
title Phasmo Journal - Build Installer
color 0A
cls
echo DEBUG: Script started


echo.
echo  ============================================================
echo   PHASMO JOURNAL - BUILD INSTALLER
echo  ============================================================
echo.
echo  This will:
echo  1. Build PhasmoJournal.exe from the .pyw source
echo  2. Package it into PhasmoJournal_Setup.exe (installer)
echo.
echo  Requirements:
echo  - Python installed (for step 1)
echo  - Inno Setup installed (for step 2)
echo    Free download: https://jrsoftware.org/isdl.php
echo.
echo  ============================================================
echo.

:: ── Find Python ─────────────────────────────────────────────────────
set PYTHON=
for %%P in (
    "%LOCALAPPDATA%\Python\bin\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
) do (
    if exist %%P if "%PYTHON%"=="" set PYTHON=%%P
)
if "%PYTHON%"=="" (
    for /f "delims=" %%i in ('where python 2^>nul') do (
        echo %%i | find /i "WindowsApps" >nul || if "%PYTHON%"=="" set PYTHON=%%i
    )
)
if "%PYTHON%"=="" (
    echo  [ERROR] Python not found. Install from python.org first.
    pause & exit /b 1
)
echo  Found Python: %PYTHON%

:: ── Find Inno Setup ─────────────────────────────────────────────────
set INNO=

:: Check all common install locations
if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" set INNO=C:\Program Files (x86)\Inno Setup 6\ISCC.exe
if exist "C:\Program Files\Inno Setup 6\ISCC.exe"       set INNO=C:\Program Files\Inno Setup 6\ISCC.exe
if exist "C:\Program Files (x86)\Inno Setup 5\ISCC.exe" set INNO=C:\Program Files (x86)\Inno Setup 5\ISCC.exe
if exist "C:\Program Files\Inno Setup 5\ISCC.exe"       set INNO=C:\Program Files\Inno Setup 5\ISCC.exe

:: Check user-level install (no admin)
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set INNO=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe
if exist "%LOCALAPPDATA%\Programs\Inno Setup 5\ISCC.exe" set INNO=%LOCALAPPDATA%\Programs\Inno Setup 5\ISCC.exe

:: Check if it is on PATH
if "%INNO%"=="" (
    where ISCC >nul 2>&1 && set INNO=ISCC
)
if "%INNO%"=="" (
    echo.
    echo  [ERROR] Inno Setup not found!
    echo.
    echo  Download and install it free from:
    echo  https://jrsoftware.org/isdl.php
    echo.
    echo  Then run this script again.
    echo.
    pause & exit /b 1
)
echo  Found Inno Setup: %INNO%
echo.

:: ── Step 1: Build EXE ───────────────────────────────────────────────
echo  [1/3] Building PhasmoJournal.exe...
echo.
%PYTHON% -m pip install pyinstaller keyboard --quiet --upgrade
%PYTHON% -m PyInstaller --onefile --windowed --name "PhasmoJournal" --clean --noconfirm "%~dp0phasmo_journal.pyw"

if not exist "%~dp0dist\PhasmoJournal.exe" (
    echo  [ERROR] EXE build failed. Check output above.
    pause & exit /b 1
)
copy "%~dp0dist\PhasmoJournal.exe" "%~dp0PhasmoJournal.exe" >nul
echo  EXE built OK.
echo.
echo  [1b/3] Building OBS mode EXE...
%PYTHON% -m PyInstaller --onefile --windowed --name "PhasmoJournal_OBS" --clean --noconfirm "%~dp0phasmo_journal.pyw" -- --obs
:: PyInstaller cant pass args, so build a tiny launcher instead
echo import sys, subprocess, os > "%~dp0_obs_launcher.py"
echo exe = os.path.join(os.path.dirname(sys.executable), "PhasmoJournal.exe") >> "%~dp0_obs_launcher.py"
echo subprocess.Popen([exe, "--obs"]) >> "%~dp0_obs_launcher.py"
%PYTHON% -m PyInstaller --onefile --windowed --name "PhasmoJournal_OBS" --clean --noconfirm "%~dp0_obs_launcher.py"
if exist "%~dp0dist\PhasmoJournal_OBS.exe" copy "%~dp0dist\PhasmoJournal_OBS.exe" "%~dp0PhasmoJournal_OBS.exe" >nul
if exist "%~dp0_obs_launcher.py" del "%~dp0_obs_launcher.py" >nul
echo  OBS launcher built OK.
echo.

:: ── Step 2: Build Installer ─────────────────────────────────────────
echo  [2/3] Building installer...
echo.
if not exist "%~dp0installer_output" mkdir "%~dp0installer_output"
"%INNO%" "%~dp0installer.iss"

if not exist "%~dp0installer_output\PhasmoJournal_Setup.exe" (
    echo  [ERROR] Installer build failed.
    pause & exit /b 1
)

:: ── Step 3: Clean up ────────────────────────────────────────────────
echo  [3/3] Cleaning up...
if exist "%~dp0dist"  rmdir /s /q "%~dp0dist"  >nul 2>&1
if exist "%~dp0build" rmdir /s /q "%~dp0build" >nul 2>&1
if exist "%~dp0PhasmoJournal.spec" del "%~dp0PhasmoJournal.spec" >nul 2>&1

echo.
echo  ============================================================
echo   SUCCESS!
echo  ============================================================
echo.
echo   Your installer is ready at:
echo   installer_output\PhasmoJournal_Setup.exe
echo.
echo   Upload this file to your GitHub releases page.
echo   Anyone can download and install it with one double-click.
echo  ============================================================
echo.
pause
